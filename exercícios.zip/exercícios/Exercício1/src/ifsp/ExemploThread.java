package ifsp;


public class ExemploThread extends Thread {
	public void run () {
		System.out.println("inicio: " + getName());
		for (int i = 1; i < 4; i++)
		System.out.println(i + "-" + getName());
		
		System.out.println("Fim: " + getName());
	}
}
