package ifsp;

public class TestaThreads {
	public static void main (String a []) {
		System.out.println("INICIO DO TESTE");
		ExemploThread t1 = new ExemploThread(),
					  t2 = new ExemploThread(),
					  t3 = new ExemploThread();
		
		t1.start();
		t2.start();
		t3.start();
		System.out.println("FIM DO TESTE");
	}
}
