package ifsp;

public class FibonacciCalculator extends Thread {
    private Painel pn;
    private int n;

    public FibonacciCalculator(Painel pn, int n) {
        this.pn = pn;
        this.n = n;
    }

    @Override
    public void run() {
        pn.getTaResultado().setText(null);
        pn.getBtLimpar().setEnabled(false);
        pn.getBtExecutar().setEnabled(false);
        calculaFibonacci();
        pn.getBtLimpar().setEnabled(true);
        pn.getBtExecutar().setEnabled(true);
    }

    private void calculaFibonacci() {
        int a = 0, b = 1;
        for (int i = 0; i < n; i++) {
            pn.getTaResultado().append(a + ", ");
            int temp = a;
            a = b;
            b += temp;
        }
    }
}
