package ifsp;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

@SuppressWarnings("serial")
public class PrimosCT extends JFrame implements ActionListener {
	private Painel pn;
	private boolean cancel; // Variável de controle do processamento.

	public PrimosCT() { // Código omitido.
		super("Números Primos Com Thread");
		setContentPane(pn = new Painel());
		pn.getBtCancelar().addActionListener(this);
		pn.getBtLimpar().addActionListener(this);
		pn.getBtExecutar().addActionListener(this);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(350, 150);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == pn.getBtExecutar()) {
			pn.getTaResultado().setText(null);
			pn.getBtLimpar().setEnabled(false);
			pn.getBtExecutar().setEnabled(false);
			calculaPrimos(Integer.parseInt(pn.getTfInicio().getText()),
					Integer.parseInt(pn.getTfFim().getText()));
			pn.getBtLimpar().setEnabled(true);
			pn.getBtExecutar().setEnabled(true);
		} else if (e.getSource() == pn.getBtLimpar()) {
			pn.getTaResultado().setText(null);
		} else {
			cancel = true;
			pn.getBtLimpar().setEnabled(true);
			pn.getBtExecutar().setEnabled(true);
		}
	}

	public void calculaPrimos(int inicio, int fim) {
		cancel = false;
		for (int n = inicio; n <= fim && !cancel; n++) {
			int i;
			for (i = 2; i < n; i++)
				if (n % i == 0)
					break;
			if (i == n)
				pn.getTaResultado().append(n + ", ");
		}
	}

//	private class Calculo extends Thread { // Classe interna
//		@Override
//		public void run() { // aciona calculo
//			calculaPrimos(Integer.parseInt(pn.getTfInicio().getText()),
//					      Integer.parseInt(pn.getTfFim().getText()));
//			pn.getBtLimpar().setEnabled(true);
//			pn.getBtExecutar().setEnabled(true);
//		}
//	}

	public static void main(String a[]) {
		SwingUtilities.invokeLater(new Runnable(){
			@Override
			public void run(){
				new PrimosCT().setVisible(true);
		}});
	}
}

