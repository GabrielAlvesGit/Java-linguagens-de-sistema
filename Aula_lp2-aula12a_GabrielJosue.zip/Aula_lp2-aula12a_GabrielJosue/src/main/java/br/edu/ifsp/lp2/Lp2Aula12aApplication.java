package br.edu.ifsp.lp2;

import java.awt.Desktop;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

@SpringBootApplication
public class Lp2Aula12aApplication extends SpringBootServletInitializer {

	public static void main(String[] args) {
		SpringApplication.run(Lp2Aula12aApplication.class, args);
		abrePaginaInicial();
	}

	private static void abrePaginaInicial() {
		System.setProperty("java.awt.headless", "false");
		try {
			Desktop.getDesktop().browse(new URI("http://localhost:8080/"));
		} catch (URISyntaxException | IOException e) {
			e.printStackTrace();
		}
	}
}
