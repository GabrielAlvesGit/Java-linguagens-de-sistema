package br.edu.ifsp.lp2;

import java.math.BigDecimal;
import java.util.Objects;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Funcionario {
	@Id
	private Integer id;
	private String nome;
	private String cargo;
	private BigDecimal salario;
	
	
	public Integer getId() {return id;}
	public void setId(Integer id) { this.id = id;}
	
	public String getNome() {return nome;}
	public void setNome(String nome) { this.nome = nome;}
	
	public String getCargo() {return cargo;}
	public void setCargo(String cargo) { this.cargo = cargo;}
	
	
	public BigDecimal getSalario() {return salario;}
	public void setSalario(BigDecimal salario) { this.salario = salario;}
	@Override
	public int hashCode() {
		return Objects.hash(cargo, id, nome, salario);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Funcionario other = (Funcionario) obj;
		return Objects.equals(cargo, other.cargo) && Objects.equals(id, other.id) && Objects.equals(nome, other.nome)
				&& Objects.equals(salario, other.salario);
	}
}
