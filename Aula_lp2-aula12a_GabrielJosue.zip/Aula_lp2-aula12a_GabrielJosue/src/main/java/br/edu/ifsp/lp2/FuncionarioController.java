package br.edu.ifsp.lp2;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/funcionarios")
public class FuncionarioController {
	@Autowired
	private FuncionarioRepositorio respositorio;
	
	@GetMapping("/busca/{filtro}")
	List<Funcionario> buscaPorFiltro(@PathVariable String filtro){
		return respositorio.buscarPorFiltro(filtro);
	}
}
