package br.edu.ifsp.lp2;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface FuncionarioRepositorio extends JpaRepository<Funcionario, Integer> {
	@Query("select f from Funcionario f where lower(f.nome) like lower(concat('%', :filtro, '%')) order by f.nome")
	public List<Funcionario> buscarPorFiltro(@Param("filtro") String filtro);
}
