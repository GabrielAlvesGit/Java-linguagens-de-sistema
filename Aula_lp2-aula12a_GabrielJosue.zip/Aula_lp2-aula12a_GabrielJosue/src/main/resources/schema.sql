drop table funcionario IF EXISTS;

CREATE TABLE funcionario (
id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
nome VARCHAR(100) NOT NULL,
cargo VARCHAR(50),
salario DECIMAL(7, 2)
);

