package br.edu.ifsp.lp2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lp2Aula12aApplicationTests {

	@Test
	void contextLoads() {
	}

}
