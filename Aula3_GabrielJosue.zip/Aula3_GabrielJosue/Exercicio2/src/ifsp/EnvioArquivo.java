package ifsp;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.Socket;

public class EnvioArquivo {
    public static void main(String[] args) {
        try (Socket clienteCS = new Socket("localhost", 1234);
             Socket clienteD = new Socket("localhost", 1235)) {

            // Enviando o nome e tamanho do arquivo
            BufferedOutputStream canalCS = new BufferedOutputStream(clienteCS.getOutputStream());
            File arquivo = new File("pneumotorax.txt");
            canalCS.write((arquivo.getName() + "\n").getBytes());
            canalCS.write((arquivo.length() + "\n").getBytes());
            canalCS.flush();
            canalCS.close();

            // Enviando o conteúdo do arquivo
            BufferedInputStream inputStream = new BufferedInputStream(new FileInputStream(arquivo));
            BufferedOutputStream canalD = new BufferedOutputStream(clienteD.getOutputStream());
            byte[] buffer = new byte[128];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                canalD.write(buffer, 0, bytesRead);
            }
            canalD.flush();
            canalD.close();

            System.out.println("Arquivo enviado com sucesso!");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}