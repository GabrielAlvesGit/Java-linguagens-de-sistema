package ifsp;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class RecepcaoArquivo {
    public static void main(String[] args) {
        System.out.println("[Criando Servidor...]");
        try (ServerSocket servidorCS = new ServerSocket(1234);
             ServerSocket servidorD = new ServerSocket(1235)) {

            while (true) {
                System.out.println("[Aguardando conexão...]");
                try (Socket clienteCS = servidorCS.accept();
                     Socket clienteD = servidorD.accept()) {

                    // Recebendo o nome e tamanho do arquivo
                    BufferedInputStream canalCS = new BufferedInputStream(clienteCS.getInputStream());
                    StringBuilder nomeArqBuilder = new StringBuilder();
                    int character;
                    while ((character = canalCS.read()) != -1 && character != '\n') {
                        nomeArqBuilder.append((char) character);
                    }
                    String nomeArq = nomeArqBuilder.toString();
                    
                    StringBuilder tamanhoBuilder = new StringBuilder();
                    while ((character = canalCS.read()) != -1 && character != '\n') {
                        tamanhoBuilder.append((char) character);
                    }
                    long tamanho = Long.parseLong(tamanhoBuilder.toString());
                    canalCS.close();

                    System.out.println("[Recebendo arquivo " + nomeArq + "]");

                    // Recebendo o conteúdo do arquivo
                    BufferedOutputStream arquivo = new BufferedOutputStream(new FileOutputStream(nomeArq));
                    BufferedInputStream canalD = new BufferedInputStream(clienteD.getInputStream());
                    byte[] buffer = new byte[128];
                    long totalRecebido = 0;
                    int bytesRead;
                    while (totalRecebido < tamanho && (bytesRead = canalD.read(buffer)) != -1) {
                        arquivo.write(buffer, 0, bytesRead);
                        totalRecebido += bytesRead;
                    }
                    arquivo.flush();
                    arquivo.close();
                    canalD.close();

                    System.out.println("[" + tamanho + " bytes recebidos]");
                } catch (IOException e) {
                    System.out.println("Problemas na recepção");
                    e.printStackTrace();
                }
            }
        } catch (IOException e) {
            System.out.println("Erro!");
            e.printStackTrace();
        }
        System.out.println("[Conexão encerrada]");
    }
}
