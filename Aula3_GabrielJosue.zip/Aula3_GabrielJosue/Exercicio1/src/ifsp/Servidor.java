package ifsp;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Servidor {
    public static void main(String[] args) {
        try {
            // Inicia o servidor na porta 12345
            ServerSocket serverSocket = new ServerSocket(12345);
            System.out.println("Servidor esperando por conexão...");

            // Aguarda conexão do cliente
            Socket socket = serverSocket.accept();
            System.out.println("Cliente conectado!");

            // Cria fluxos de entrada e saída
            DataInputStream inputStream = new DataInputStream(socket.getInputStream());
            DataOutputStream outputStream = new DataOutputStream(socket.getOutputStream());

            // Recebe o número do cliente
            double numeroRecebido = inputStream.readDouble();
            System.out.println("Número recebido do cliente: " + numeroRecebido);

            // Calcula a raiz quadrada
            double resultado = Math.sqrt(numeroRecebido);

            // Envia o resultado de volta para o cliente
            outputStream.writeDouble(resultado);
            System.out.println("Resultado enviado para o cliente: " + resultado);

            // Fecha as conexões
            socket.close();
            serverSocket.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}