package ifsp;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

public class Cliente {
    public static void main(String[] args) {
        try {
            // Conecta ao servidor na porta 12345
            Socket socket = new Socket("localhost", 12345);
            System.out.println("Conectado ao servidor.");

            // Cria fluxos de entrada e saída
            DataInputStream inputStream = new DataInputStream(socket.getInputStream());
            DataOutputStream outputStream = new DataOutputStream(socket.getOutputStream());

            // Solicita o número ao usuário
            Scanner scanner = new Scanner(System.in);
            System.out.print("Digite um número real: ");
            double numeroEnviado = scanner.nextDouble();

            // Envia o número para o servidor
            outputStream.writeDouble(numeroEnviado);

            // Recebe o resultado do servidor
            double resultado = inputStream.readDouble();
            System.out.println("Resultado recebido do servidor: " + resultado);

            // Fecha as conexões
            socket.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}