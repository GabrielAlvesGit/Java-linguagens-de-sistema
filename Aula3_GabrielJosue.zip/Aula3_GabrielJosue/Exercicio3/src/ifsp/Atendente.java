package ifsp;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

public class Atendente implements Runnable {

    private final Socket clientSocket;

    public Atendente(Socket clientSocket) {
        this.clientSocket = clientSocket;
    }

    @Override
    public void run() {
        try (DataInputStream inputStream = new DataInputStream(clientSocket.getInputStream());
             DataOutputStream outputStream = new DataOutputStream(clientSocket.getOutputStream())) {

            // Recebe peso e altura do cliente
            double peso = inputStream.readDouble();
            double altura = inputStream.readDouble();

            // Calcula o IMC
            double imc = calcularIMC(peso, altura);

            // Envia o resultado de volta ao cliente
            outputStream.writeDouble(imc);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private double calcularIMC(double peso, double altura) {
        return peso / (altura * altura);
    }
}