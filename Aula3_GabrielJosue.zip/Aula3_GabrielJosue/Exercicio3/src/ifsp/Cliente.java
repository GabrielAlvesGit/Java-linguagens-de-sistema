package ifsp;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

public class Cliente {

    public static void main(String[] args) {
        try (Socket socket = new Socket("localhost", 12347);
             Scanner scanner = new Scanner(System.in);
             DataInputStream inputStream = new DataInputStream(socket.getInputStream());
             DataOutputStream outputStream = new DataOutputStream(socket.getOutputStream())) {

            System.out.print("Informe o peso (em kg): ");
            double peso = scanner.nextDouble();

            System.out.print("Informe a altura (em metros): ");
            double altura = scanner.nextDouble();

            // Envia peso e altura para o servidor
            outputStream.writeDouble(peso);
            outputStream.writeDouble(altura);

            // Recebe o IMC calculado pelo servidor
            double imc = inputStream.readDouble();

            System.out.println("O seu IMC é: " + imc);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}