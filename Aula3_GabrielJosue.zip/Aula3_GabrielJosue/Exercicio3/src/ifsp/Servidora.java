package ifsp;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Servidora {

    public static void main(String[] args) {
        ServerSocket serverSocket = null;

        try {
            serverSocket = new ServerSocket(12347);
            System.out.println("Servidor multithread aguardando conexões...");

            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Novo cliente conectado");

                Atendente atendente = new Atendente(clientSocket);
                Thread atendenteThread = new Thread(atendente);
                atendenteThread.start();
            }

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (serverSocket != null && !serverSocket.isClosed()) {
                    serverSocket.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
