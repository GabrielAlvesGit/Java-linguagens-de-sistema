package ifsp.edu.br;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/MilhasParaQuilometrosServlet")
public class MilhasParaQuilometrosServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        double medida = Double.parseDouble(request.getParameter("medida"));
        double resultado = medida * 1.61;

        response.setContentType("text/html");
        response.getWriter().println("<h2>O resultado da conversão é: " + resultado + " Km</h2>");
    }
}
