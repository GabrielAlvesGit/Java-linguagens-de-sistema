package ifsp.edu.br;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Exercicio02
 */
@WebServlet("/exercicio03")
public class Exercicio03 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        double temperatura = Double.parseDouble(request.getParameter("temperatura"));
        String conversao = request.getParameter("conversao");
        double resultado = 0;

        switch (conversao) {
            case "celsiusToFahrenheit":
                resultado = celsiusToFahrenheit(temperatura);
                break;
            case "fahrenheitToCelsius":
                resultado = fahrenheitToCelsius(temperatura);
                break;
            case "celsiusToKelvin":
                resultado = celsiusToKelvin(temperatura);
                break;
            case "kelvinToCelsius":
                resultado = kelvinToCelsius(temperatura);
                break;
            case "fahrenheitToKelvin":
                resultado = fahrenheitToKelvin(temperatura);
                break;
            case "kelvinToFahrenheit":
                resultado = kelvinToFahrenheit(temperatura);
                break;
            default:
                // Caso de conversão inválido
                break;
        }

        response.setContentType("text/html");
        response.getWriter().println("<h2>O resultado da conversão é: " + resultado + "</h2>");
    }

    private double celsiusToFahrenheit(double celsius) {
        return (celsius * 9/5) + 32;
    }

    private double fahrenheitToCelsius(double fahrenheit) {
        return (fahrenheit - 32) * 5/9;
    }

    private double celsiusToKelvin(double celsius) {
        return celsius + 273.15;
    }

    private double kelvinToCelsius(double kelvin) {
        return kelvin - 273.15;
    }

    private double fahrenheitToKelvin(double fahrenheit) {
        return (fahrenheit + 459.67) * 5/9;
    }

    private double kelvinToFahrenheit(double kelvin) {
        return (kelvin * 9/5) - 459.67;
    }
}