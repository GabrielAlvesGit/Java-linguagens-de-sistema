import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class AutenticacaoController extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

       
        if (username.equals("admin") && password.equals("admin")) {
            HttpSession session = request.getSession();
            session.setAttribute("username", username);
            System.out.println("Login bem-sucedido para o usuário: " + username);
            response.sendRedirect("pedido.html");
        } else {
            System.out.println("Login falhou para o usuário: " + username);
            response.sendRedirect("login.html");
        }
    }
}