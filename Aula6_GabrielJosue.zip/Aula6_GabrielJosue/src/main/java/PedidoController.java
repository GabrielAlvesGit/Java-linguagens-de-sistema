import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class PedidoController extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String username = (String) session.getAttribute("username");

        if (username == null) {
            System.out.println("Usuário não autenticado, redirecionando para a página de login");
            response.sendRedirect("login.html");
            return;
        }

       
        String nome = request.getParameter("nome");
        String cpf = request.getParameter("cpf");
        String sexo = request.getParameter("sexo");
        String endereco = request.getParameter("endereco");
        String cidade = request.getParameter("cidade");
        String estado = request.getParameter("estado");
        String pagamento = request.getParameter("pagamento");
        String parcelamento = request.getParameter("parcelamento");

       
        response.sendRedirect("final.html");
    }
}