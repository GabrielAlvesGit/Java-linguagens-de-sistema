package br.edu.ifsp.lp2.servlets;

import java.io.IOException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.edu.ifsp.lp2.entities.Estudante;
import br.edu.ifsp.lp2.persistence.JpaUtil;

@WebServlet("/EstudanteController")
public class EstudanteController extends HttpServlet {
    private EntityManager entityManager;
    private EntityTransaction transaction;
    private RequestDispatcher destination;

    public EstudanteController() {
        entityManager = JpaUtil.getEntityManager();
        transaction = entityManager.getTransaction();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setAttribute("estudantes", consultaEstudantes());
        destination = getServletContext().getRequestDispatcher("/estudante/resultConsulta.jsp");
        destination.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Long id = null;
        String nome = request.getParameter("nome");
        char sexo = request.getParameter("sexo").charAt(0);
        boolean deficiencia = request.getParameter("deficiencia") != null;
        double ira = Double.parseDouble(request.getParameter("ira"));

        try {
            if (request.getParameter("op").equals("alteracao") || request.getParameter("op").equals("exclusao")) {
                id = Long.parseLong(request.getParameter("id"));
            }

            if (request.getParameter("op").equals("insercao") || request.getParameter("op").equals("alteracao")) {
                if (request.getParameter("id") != null && !request.getParameter("id").isEmpty()) {
                    id = Long.parseLong(request.getParameter("id"));
                }
            }

            if (request.getParameter("op").equals("insercao")) {
                try {
                    insereEstudante(nome, sexo, deficiencia, ira);
                    request.setAttribute("resultado", true);
                } catch (Exception e) {
                    request.setAttribute("resultado", false);
                }
                destination = getServletContext().getRequestDispatcher("/estudante/resultInsercao.jsp");
            } else if (request.getParameter("op").equals("alteracao")) {
                try {
                    alteraEstudante(id, nome, sexo, deficiencia, ira);
                    request.setAttribute("resultado", true);
                } catch (Exception e) {
                    request.setAttribute("resultado", false);
                }
                destination = getServletContext().getRequestDispatcher("/estudante/resultAlteracao.jsp");
            } else if (request.getParameter("op").equals("exclusao")) {
                try {
                    excluiEstudante(id);
                    request.setAttribute("resultado", true);
                } catch (Exception e) {
                    request.setAttribute("resultado", false);
                }
                destination = getServletContext().getRequestDispatcher("/estudante/resultExclusao.jsp");
            }
            destination.forward(request, response);
        } catch (Exception e) {
            destination = getServletContext().getRequestDispatcher("/erroEntrada.jsp");
            destination.forward(request, response);
        }
    }

    @SuppressWarnings("unchecked")
    public List<Estudante> consultaEstudantes() {
        Query query = entityManager.createQuery("select e from Estudante e");
        return query.getResultList();
    }

    public void insereEstudante(String nome, char sexo, boolean deficiencia, double ira) {
        transaction.begin();
        Estudante estudante = new Estudante();
        estudante.setNome(nome);
        estudante.setSexo(sexo);
        estudante.setDeficiencia(deficiencia);
        estudante.setIra(ira);
        entityManager.persist(estudante);
        transaction.commit();
    }

    public void alteraEstudante(Long id, String nome, char sexo, boolean deficiencia, double ira) {
        transaction.begin();
        Estudante estudante = entityManager.find(Estudante.class, id);
        estudante.setNome(nome);
        estudante.setSexo(sexo);
        estudante.setDeficiencia(deficiencia);
        estudante.setIra(ira);
        transaction.commit();
    }

    public void excluiEstudante(Long id) {
        transaction.begin();
        Estudante estudante = entityManager.find(Estudante.class, id);
        entityManager.remove(estudante);
        transaction.commit();
    }
}
