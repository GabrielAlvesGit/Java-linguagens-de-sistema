INSERT INTO estudante (nome, sexo, deficiencia, ira) VALUES ('João Silva', 'M', true, 9.2);
INSERT INTO estudante (nome, sexo, deficiencia, ira) VALUES ('Gabriel', 'M', true, 9.2);
INSERT INTO estudante (nome, sexo, deficiencia, ira) VALUES ('Kayser', 'M', true, 9.2);
