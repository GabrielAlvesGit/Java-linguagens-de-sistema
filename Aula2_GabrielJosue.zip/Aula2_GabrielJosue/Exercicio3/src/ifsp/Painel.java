// Classe Painel
package ifsp;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

@SuppressWarnings("serial")
public class Painel extends JPanel {
    private JTextField tfInicio, tfFim;
    private JButton btCancelar, btLimpar, btExecutar;
    private JTextArea taResultado;
    public boolean cancel;  // Modificado para public

    public Painel() {
        // Configura o layout do painel.
        setLayout(new BorderLayout());

        // Configura os componentes do painel superior.
        JPanel pnSup = new JPanel(new GridLayout(1, 4, 3, 3));
        pnSup.add(new JLabel("Inicio", JLabel.RIGHT));
        pnSup.add(tfInicio = new JTextField());
        pnSup.add(new JLabel("Fim", JLabel.RIGHT));
        pnSup.add(tfFim = new JTextField());

        // Configura os componentes da área central.
        JScrollPane sp = new JScrollPane(taResultado = new JTextArea());
        taResultado.setEditable(false);
        taResultado.setLineWrap(true);
        taResultado.setWrapStyleWord(true);
        sp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        // Configura os componentes do painel inferior.
        JPanel pnInf = new JPanel(new GridLayout(1, 3, 3, 3));
        pnInf.add(btCancelar = new JButton("Cancelar"));
        pnInf.add(btLimpar = new JButton("Limpar"));
        pnInf.add(btExecutar = new JButton("Executar"));

        // Configura os componentes do painel principal.
        JPanel pnPrinc = new JPanel();
        pnPrinc.add(pnInf);
        add("North", pnSup);
        add("Center", sp);
        add("South", pnPrinc);
    }

    public JButton getBtCancelar() {
        return btCancelar;
    }

    public JButton getBtLimpar() {
        return btLimpar;
    }

    public JButton getBtExecutar() {
        return btExecutar;
    }

    public JTextArea getTaResultado() {
        return taResultado;
    }

    public JTextField getTfInicio() {
        return tfInicio;
    }

    public JTextField getTfFim() {
        return tfFim;
    }
}
