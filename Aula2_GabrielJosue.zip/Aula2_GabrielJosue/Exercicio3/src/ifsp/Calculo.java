// Classe Calculo
package ifsp;

import javax.swing.SwingUtilities;

public class Calculo extends Thread {
    private Painel pn;

    public Calculo(Painel pn) {
        this.pn = pn;
    }

    @Override
    public void run() {
        calculaPrimos(Integer.parseInt(pn.getTfInicio().getText()),
                      Integer.parseInt(pn.getTfFim().getText()));
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                pn.getBtLimpar().setEnabled(true);
                pn.getBtExecutar().setEnabled(true);
            }
        });
    }

    private void calculaPrimos(int inicio, int fim) {
        pn.cancel = false;
        for (int n = inicio; n <= fim && !pn.cancel; n++) {
            int i;
            for (i = 2; i < n; i++)
                if (n % i == 0)
                    break;
            if (i == n)
                SwingUtilities.invokeLater(new Runnable() {
                    @Override
                    public void run() {
                        pn.getTaResultado().append(n + ", ");
                    }
                });
        }
    }
}
