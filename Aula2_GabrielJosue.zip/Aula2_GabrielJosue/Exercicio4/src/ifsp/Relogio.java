package ifsp;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

public class Relogio extends JFrame {

    public Relogio() {
        super("Relógio");
        PainelRelogio relogio = new PainelRelogio();
        relogio.inicia();
        getContentPane().add(relogio);  // Fix: Just add the component without specifying constraints
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(250, 65);  // Corrected method name to setSize
    }

    public static void main(String a[]) {
        SwingUtilities.invokeLater(() -> {
            new Relogio().setVisible(true);
        });
    }
}
