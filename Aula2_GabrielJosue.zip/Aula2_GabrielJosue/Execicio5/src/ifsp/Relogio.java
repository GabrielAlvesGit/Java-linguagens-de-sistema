package ifsp;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class Relogio extends JFrame {

    private static final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);

    public Relogio() {
        super("Relógio");
        PainelRelogio relogio = new PainelRelogio();
        relogio.inicia();
        getContentPane().add(relogio);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(250, 65);
    }

    public static void main(String a[]) {
        SwingUtilities.invokeLater(() -> {
            new Relogio().setVisible(true);
        });

        // Schedule the user thread with the executor service
        scheduler.scheduleAtFixedRate(() -> {
            SwingUtilities.invokeLater(() -> {
                // Update UI components here
                // This code runs on the user thread
            });
        }, 0, 100, TimeUnit.MILLISECONDS);
    }
}
