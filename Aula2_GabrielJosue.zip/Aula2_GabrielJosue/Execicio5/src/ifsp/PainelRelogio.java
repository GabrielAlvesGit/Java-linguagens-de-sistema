package ifsp;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class PainelRelogio extends JPanel implements Runnable {
    private Thread trRelogio;
    private DateTimeFormatter dtf;
    private JLabel lbRelogio;

    public PainelRelogio() {
        lbRelogio = new JLabel();
        add(lbRelogio);
        dtf = DateTimeFormatter.ofPattern("E dd/MM/yyyy HH:mm:ss");  // Corrected date pattern
    }

    public void inicia() {
        trRelogio = new Thread(this, "Relógio");
        trRelogio.start();
    }

    public void run() {
        while (Thread.currentThread() == trRelogio) {
            repaint();
            try {
                Thread.sleep(100);
                lbRelogio.setText(dtf.format(LocalDateTime.now()));
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
