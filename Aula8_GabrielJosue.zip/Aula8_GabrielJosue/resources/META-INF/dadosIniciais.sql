insert into Estudante (id, nome, sexo, deficiencia, ira) values (1, 'Caio', 'M', false, 10);
insert into Estudante (id, nome, sexo, deficiencia, ira) values (2,'Gabriel', 'M', false, 10);
insert into Estudante (id, nome, sexo, deficiencia, ira) values (3, 'Kayan', 'M', false, 10);
insert into Estudante (id, nome, sexo, deficiencia, ira) values (4, 'Cletinho do Pneu', 'f', false, 10);
