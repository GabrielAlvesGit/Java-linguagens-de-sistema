insert into Curso (id, descricao, cargaHoraria) values (1, 'ADS', '120h');
insert into Curso (id, descricao, cargaHoraria) values (2, 'BCI', '150h');
insert into Curso (id, descricao, cargaHoraria) values (3, 'Dados', '160h');

insert into Estudante (id, nome, sexo, deficiencia, ira, curso_id) values (1, 'Caio', 'M', false, 10);
insert into Estudante (id, nome, sexo, deficiencia, ira, curso_id) values (2,'Gabriel', 'M', false, 10);
insert into Estudante (id, nome, sexo, deficiencia, ira, curso_id) values (3, 'Kayan', 'M', false, 10);
insert into Estudante (id, nome, sexo, deficiencia, ira, curso_id) values (4, 'Cletinho do Pneu', 'f', false, 10);
